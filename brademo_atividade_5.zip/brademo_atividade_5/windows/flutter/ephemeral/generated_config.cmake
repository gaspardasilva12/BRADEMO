# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Gaspar\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Gaspar\\flutter"
  "PROJECT_DIR=c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5"
  "FLUTTER_ROOT=C:\\Users\\Gaspar\\flutter"
  "FLUTTER_EPHEMERAL_DIR=c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5"
  "FLUTTER_TARGET=c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZGI1MGUyMDE2OA==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NDI1Y2ZiNTRkMA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS40"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=c:\\Users\\Gaspar\\OneDrive\\Área de Trabalho\\brademo_atidade_5\\.dart_tool\\package_config.json"
)
